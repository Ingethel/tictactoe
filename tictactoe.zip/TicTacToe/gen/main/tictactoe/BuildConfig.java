/** Automatically generated file. DO NOT MODIFY */
package main.tictactoe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}